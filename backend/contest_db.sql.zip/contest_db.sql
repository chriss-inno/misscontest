-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2016 at 12:10 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `contest_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_articles`
--

CREATE TABLE IF NOT EXISTS `miss_articles` (
`id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `introtext` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `fulltext` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `catid` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `hits` int(11) NOT NULL,
  `access` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_article_categories`
--

CREATE TABLE IF NOT EXISTS `miss_article_categories` (
`id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `parentid` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `access` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_contestants`
--

CREATE TABLE IF NOT EXISTS `miss_contestants` (
`id` int(10) unsigned NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nick_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `region_id` int(11) NOT NULL,
  `district_id` int(11) NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `registration_date` date NOT NULL,
  `profile_note` mediumtext COLLATE utf8_unicode_ci,
  `profile_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `blocked` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `contest_year` int(11) NOT NULL,
  `hints` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `miss_contestants`
--

INSERT INTO `miss_contestants` (`id`, `first_name`, `last_name`, `middle_name`, `nick_name`, `full_name`, `email`, `phone`, `region_id`, `district_id`, `city`, `zone`, `address`, `category_id`, `registration_date`, `profile_note`, `profile_image`, `status`, `dob`, `blocked`, `contest_year`, `hints`, `created_at`, `updated_at`) VALUES
(4, '', '', NULL, NULL, 'Stella Mkondya', '', '', 1, 1, '', '', NULL, NULL, '2016-05-07', 'SDFSDFSDF', '20160507145335_joomla.png', 'Active', '2016-08-24', 'No', 2016, 0, '2016-05-07 11:54:02', '2016-05-07 11:54:02'),
(5, '', '', NULL, NULL, 'test', '', '', 1, 2, '', '', NULL, NULL, '2016-05-08', 'hhhh', '20160508123752_2016-Happy-Mothers-Day.jpeg', 'Active', '1999-05-01', 'No', 2016, 0, '2016-05-08 09:38:35', '2016-05-08 09:38:35'),
(6, '', '', NULL, NULL, 'Stella Mkondya', '', '', 1, 1, '', '', NULL, NULL, '2016-05-15', 'SDFSDFSDF', '20160515101919_20160508123752_2016-Happy-Mothers-Day.jpeg', 'Active', '2016-08-24', 'No', 2016, 1, '2016-05-15 07:23:19', '2016-05-15 07:19:23');

-- --------------------------------------------------------

--
-- Table structure for table `miss_contestant_galleries`
--

CREATE TABLE IF NOT EXISTS `miss_contestant_galleries` (
`id` int(10) unsigned NOT NULL,
  `contestant_id` int(11) NOT NULL,
  `gallery_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  `created_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `hits` int(11) NOT NULL,
  `access` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `miss_contestant_galleries`
--

INSERT INTO `miss_contestant_galleries` (`id`, `contestant_id`, `gallery_path`, `position`, `created_by`, `publish_up`, `publish_down`, `hits`, `access`, `created_at`, `updated_at`) VALUES
(9, 4, '4_20160508075304_IMG-20151115-WA0000.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-08 04:53:04', '2016-05-08 04:53:04'),
(11, 5, '5_20160508123859_1.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-08 09:39:00', '2016-05-08 09:39:00'),
(12, 5, '5_20160508123900_2.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-08 09:39:00', '2016-05-08 09:39:00'),
(13, 5, '5_20160508123900_3.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-08 09:39:00', '2016-05-08 09:39:00'),
(14, 5, '5_20160508123900_5.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-08 09:39:00', '2016-05-08 09:39:00'),
(15, 5, '5_20160508123900_6.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-08 09:39:00', '2016-05-08 09:39:00'),
(20, 5, '5_20160515095318_avatar1.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 06:53:18', '2016-05-15 06:53:18'),
(21, 5, '5_20160515095323_20160507145335_joomla.png', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 06:53:23', '2016-05-15 06:53:23'),
(22, 5, '5_20160515095330_20160508123752_2016-Happy-Mothers-Day.jpeg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 06:53:30', '2016-05-15 06:53:30'),
(23, 6, '6_20160515102809_20160507145335_joomla.png', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 07:28:09', '2016-05-15 07:28:09'),
(24, 6, '6_20160515102809_20160508123752_2016-Happy-Mothers-Day.jpeg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 07:28:09', '2016-05-15 07:28:09'),
(25, 6, '6_20160515102809_20160515101830_avatar1.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 07:28:09', '2016-05-15 07:28:09'),
(26, 6, '6_20160515102809_20160515101919_20160508123752_2016-Happy-Mothers-Day.jpeg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 07:28:09', '2016-05-15 07:28:09'),
(27, 6, '6_20160515102810_avatar1.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 07:28:10', '2016-05-15 07:28:10'),
(28, 6, '6_20160515102917_20160507141311_4.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 07:29:17', '2016-05-15 07:29:17'),
(29, 6, '6_20160515102923_20160507140407_6.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 07:29:23', '2016-05-15 07:29:23'),
(30, 6, '6_20160515102933_20160507140259_avatar1.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 07:29:33', '2016-05-15 07:29:33'),
(31, 6, '6_20160515102933_20160507140841_5.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 07:29:33', '2016-05-15 07:29:33'),
(32, 6, '6_20160515102933_20160507143147_5.jpg', 0, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, '2016-05-15 07:29:33', '2016-05-15 07:29:33');

-- --------------------------------------------------------

--
-- Table structure for table `miss_contestant_questions`
--

CREATE TABLE IF NOT EXISTS `miss_contestant_questions` (
`id` int(10) unsigned NOT NULL,
  `question_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `question_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `question_category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_contests`
--

CREATE TABLE IF NOT EXISTS `miss_contests` (
`id` int(10) unsigned NOT NULL,
  `contest_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `main_organiser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `end_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `event_location` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `phone1` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `phone2` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `phone3` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `default` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'enabled',
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `miss_contests`
--

INSERT INTO `miss_contests` (`id`, `contest_name`, `description`, `main_organiser`, `start_date`, `end_date`, `event_location`, `address`, `phone1`, `phone2`, `phone3`, `default`, `status`, `input_by`, `created_at`, `updated_at`) VALUES
(1, 'Reds Miss Tanzania 2016 Contest', '1', '', '1', '1', '1', '1', '1', '1', '1', 'Yes', 'enabled', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `miss_contest_feedbacks`
--

CREATE TABLE IF NOT EXISTS `miss_contest_feedbacks` (
`id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_districts`
--

CREATE TABLE IF NOT EXISTS `miss_districts` (
`id` int(10) unsigned NOT NULL,
  `district_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `region_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `miss_districts`
--

INSERT INTO `miss_districts` (`id`, `district_name`, `region_id`, `created_at`, `updated_at`) VALUES
(1, 'Ilala', 1, '2016-05-07 07:46:34', '0000-00-00 00:00:00'),
(2, 'Ubungo', 1, '2016-05-07 07:46:34', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `miss_events`
--

CREATE TABLE IF NOT EXISTS `miss_events` (
`id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_migrations`
--

CREATE TABLE IF NOT EXISTS `miss_migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `miss_migrations`
--

INSERT INTO `miss_migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2015_12_26_131550_create_articles_table', 1),
('2015_12_26_131607_create_article_categories_table', 1),
('2015_12_26_131638_create_contestants_table', 1),
('2015_12_26_131729_create_contestant_galleries_table', 1),
('2015_12_26_131744_create_events_table', 1),
('2015_12_26_131809_create_contest_feedbacks_table', 1),
('2015_12_26_131900_create_user_rights_table', 1),
('2015_12_26_131927_create_rights_categories_table', 1),
('2016_01_19_133633_create_user_phones_table', 1),
('2016_01_19_133746_create_user_addresses_table', 1),
('2016_01_19_134424_create_user_login_activities_table', 1),
('2016_01_19_134513_create_user_categories_table', 1),
('2016_01_21_023525_create_sessions_table', 1),
('2016_01_22_193226_create_districts_table', 1),
('2016_01_22_193243_create_regions_table', 1),
('2016_05_07_150556_create_visitors_reviews_table', 2),
('2016_05_08_075858_create_contestant_questions_table', 3),
('2016_05_08_103615_create_review_answers_table', 4),
('2016_05_17_122751_create_site_setups_table', 5),
('2016_05_17_123452_create_contests_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `miss_password_resets`
--

CREATE TABLE IF NOT EXISTS `miss_password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_regions`
--

CREATE TABLE IF NOT EXISTS `miss_regions` (
`id` int(10) unsigned NOT NULL,
  `region_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `zoneID` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `miss_regions`
--

INSERT INTO `miss_regions` (`id`, `region_name`, `zoneID`, `created_at`, `updated_at`) VALUES
(1, 'Dar es salaam', 0, '2016-05-07 07:45:46', '0000-00-00 00:00:00'),
(2, 'Morogoro', 0, '2016-05-07 07:45:46', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `miss_review_answers`
--

CREATE TABLE IF NOT EXISTS `miss_review_answers` (
`id` int(10) unsigned NOT NULL,
  `answer` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `question_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_rights_categories`
--

CREATE TABLE IF NOT EXISTS `miss_rights_categories` (
`id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_sessions`
--

CREATE TABLE IF NOT EXISTS `miss_sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8_unicode_ci,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_site_setups`
--

CREATE TABLE IF NOT EXISTS `miss_site_setups` (
`id` int(10) unsigned NOT NULL,
  `site_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `postal_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `physical_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `contact_person` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `contact_person_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `website` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `phone1` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `phone2` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `phone3` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `miss_site_setups`
--

INSERT INTO `miss_site_setups` (`id`, `site_name`, `description`, `postal_address`, `physical_address`, `contact_person`, `contact_person_title`, `website`, `email`, `phone1`, `phone2`, `phone3`, `created_at`, `updated_at`) VALUES
(1, 'Miss Tanzania Contest', 'Contest rating for various occations', 'P.O.Box 72330 Dar es salaam', 'Sinza Kwaremi,Shekilango road', 'Mathayo Maftcha', 'Director general', '1', 'info@misscontest.bizplusnet.com', '(255) 714 991 449', '(255) 755 390 168', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `miss_users`
--

CREATE TABLE IF NOT EXISTS `miss_users` (
`id` int(10) unsigned NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nick_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `registration_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inactive',
  `user_level` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `blocked` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_success_login` datetime NOT NULL,
  `last_logout` datetime NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `miss_users`
--

INSERT INTO `miss_users` (`id`, `first_name`, `last_name`, `middle_name`, `nick_name`, `email`, `category_id`, `registration_date`, `user_note`, `status`, `user_level`, `blocked`, `username`, `password`, `last_success_login`, `last_logout`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'Administrator', NULL, NULL, 'chriss.innocent@gmail.com', NULL, '', '', 'Active', 'administrator', 0, 'admin', '$2y$10$qR/kDaHSsUbuc4KY7TCPEu7N1Yl8aSmrAEZD442gFsrQWGRguYxR6', '2016-05-15 02:58:26', '2016-05-15 10:41:46', 'juPJM3YhUw6sKEWZVl9Ga5GLoOrKxqVSEyJwcWigM3qcU7KTo45wZjNDWmFI', '2016-05-15 11:58:26', '2016-05-15 11:58:26');

-- --------------------------------------------------------

--
-- Table structure for table `miss_user_addresses`
--

CREATE TABLE IF NOT EXISTS `miss_user_addresses` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  `physical_location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `post_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `region` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `zip_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_user_categories`
--

CREATE TABLE IF NOT EXISTS `miss_user_categories` (
`id` int(10) unsigned NOT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `create_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_user_login_activities`
--

CREATE TABLE IF NOT EXISTS `miss_user_login_activities` (
`id` int(10) unsigned NOT NULL,
  `activity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userid` int(11) NOT NULL,
  `dat_logged` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_user_phones`
--

CREATE TABLE IF NOT EXISTS `miss_user_phones` (
`id` int(10) unsigned NOT NULL,
  `user_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_user_rights`
--

CREATE TABLE IF NOT EXISTS `miss_user_rights` (
`id` int(10) unsigned NOT NULL,
  `right_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `miss_visitors_reviews`
--

CREATE TABLE IF NOT EXISTS `miss_visitors_reviews` (
`id` int(10) unsigned NOT NULL,
  `contestant_id` int(11) NOT NULL,
  `contents` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reviewed_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_reviewed` datetime NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `approved_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `miss_articles`
--
ALTER TABLE `miss_articles`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_article_categories`
--
ALTER TABLE `miss_article_categories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_contestants`
--
ALTER TABLE `miss_contestants`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_contestant_galleries`
--
ALTER TABLE `miss_contestant_galleries`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_contestant_questions`
--
ALTER TABLE `miss_contestant_questions`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_contests`
--
ALTER TABLE `miss_contests`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_contest_feedbacks`
--
ALTER TABLE `miss_contest_feedbacks`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_districts`
--
ALTER TABLE `miss_districts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_events`
--
ALTER TABLE `miss_events`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_password_resets`
--
ALTER TABLE `miss_password_resets`
 ADD KEY `password_resets_email_index` (`email`), ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `miss_regions`
--
ALTER TABLE `miss_regions`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_review_answers`
--
ALTER TABLE `miss_review_answers`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_rights_categories`
--
ALTER TABLE `miss_rights_categories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_sessions`
--
ALTER TABLE `miss_sessions`
 ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `miss_site_setups`
--
ALTER TABLE `miss_site_setups`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_users`
--
ALTER TABLE `miss_users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`), ADD UNIQUE KEY `users_username_unique` (`username`);

--
-- Indexes for table `miss_user_addresses`
--
ALTER TABLE `miss_user_addresses`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_user_categories`
--
ALTER TABLE `miss_user_categories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_user_login_activities`
--
ALTER TABLE `miss_user_login_activities`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_user_phones`
--
ALTER TABLE `miss_user_phones`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_user_rights`
--
ALTER TABLE `miss_user_rights`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miss_visitors_reviews`
--
ALTER TABLE `miss_visitors_reviews`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `miss_articles`
--
ALTER TABLE `miss_articles`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_article_categories`
--
ALTER TABLE `miss_article_categories`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_contestants`
--
ALTER TABLE `miss_contestants`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `miss_contestant_galleries`
--
ALTER TABLE `miss_contestant_galleries`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `miss_contestant_questions`
--
ALTER TABLE `miss_contestant_questions`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_contests`
--
ALTER TABLE `miss_contests`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `miss_contest_feedbacks`
--
ALTER TABLE `miss_contest_feedbacks`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_districts`
--
ALTER TABLE `miss_districts`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `miss_events`
--
ALTER TABLE `miss_events`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_regions`
--
ALTER TABLE `miss_regions`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `miss_review_answers`
--
ALTER TABLE `miss_review_answers`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_rights_categories`
--
ALTER TABLE `miss_rights_categories`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_site_setups`
--
ALTER TABLE `miss_site_setups`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `miss_users`
--
ALTER TABLE `miss_users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `miss_user_addresses`
--
ALTER TABLE `miss_user_addresses`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_user_categories`
--
ALTER TABLE `miss_user_categories`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_user_login_activities`
--
ALTER TABLE `miss_user_login_activities`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_user_phones`
--
ALTER TABLE `miss_user_phones`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_user_rights`
--
ALTER TABLE `miss_user_rights`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miss_visitors_reviews`
--
ALTER TABLE `miss_visitors_reviews`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
